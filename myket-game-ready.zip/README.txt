Package name:   com.iran.antiguardign.game
Product id:     Subscription._8500  (in www/index.html -> VIP_SKU and data-sku)
Public key:     in myket-iab-plugin/src/ir/myket/example/iab/InAppBillingPlugin.java
GitHub:         put all files in the root of the repo -> Actions -> Build Android APK -> Run workflow
                then download "game-apk" from the bottom of the run page.
