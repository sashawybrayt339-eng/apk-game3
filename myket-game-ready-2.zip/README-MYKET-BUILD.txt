# Myket Cordova game build

- Cordova package ID: `com.iran.antiguardian.game`
- Subscription product ID: `Subscription._850`
- VIP artwork: `www/vip.jpg`
- Existing Myket plugin sources are retained from the supplied game archive.
- GitHub Actions workflow: `.github/workflows/build.yml`

## Important
The separately uploaded `myket-iab-cordova-plugin-master.zip` is an old Google Play billing plugin, not a Myket-specific plugin, so it was not substituted into this project. Product ID/public key preferences in `config.xml` are metadata only; the existing plugin's documented API must be called by the game's purchase button to complete a real purchase. Test with Myket and verify the plugin's expected API before publishing.
